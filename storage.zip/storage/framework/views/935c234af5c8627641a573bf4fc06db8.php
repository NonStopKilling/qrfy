

<?php $__env->startSection('title', 'Eliminar activo | QRFY'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-3xl">
    <?php if(($role ?? 'tecnico') !== 'admin'): ?>
        <section class="rounded-3xl border border-amber-300 bg-white p-8 text-center shadow-xl">
            <h2 class="title-font text-3xl font-bold text-amber-900">Acceso denegado</h2>
            <p class="mt-3 text-amber-700">Solo el administrador puede borrar fichas.</p>
            <a href="<?php echo e(route('dashboard.assets.index', ['role' => $role ?? 'tecnico'])); ?>" class="mt-6 inline-flex rounded-2xl bg-black px-5 py-3 font-semibold text-white hover:bg-zinc-800">Volver</a>
        </section>
    <?php else: ?>
        <section class="rounded-3xl border border-red-300 bg-white p-8 text-center shadow-xl">
            <p class="text-xs uppercase tracking-[0.2em] text-red-500">Eliminar</p>
            <h2 class="title-font mt-1 text-3xl font-bold text-red-900">Eliminar equipo</h2>
            <p class="mt-3 text-slate-600">Esta acción no se puede deshacer.</p>

            <div class="mx-auto mt-6 max-w-md rounded-2xl border border-red-200 bg-red-50 p-4 text-left text-sm text-red-700">
                <p class="font-semibold"><?php echo e($asset->name); ?></p>
                <p><?php echo e($asset->serial_number); ?></p>
            </div>

            <div class="mt-6 flex flex-wrap justify-center gap-3">
                <a href="<?php echo e(route('dashboard.assets.index', ['role' => $role])); ?>" class="rounded-2xl border border-slate-300 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-100">Cancelar</a>
                <button class="rounded-2xl bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700">Eliminar activo</button>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\qrfy\qrfy-app\resources\views\dashboard\assets\delete.blade.php ENDPATH**/ ?>