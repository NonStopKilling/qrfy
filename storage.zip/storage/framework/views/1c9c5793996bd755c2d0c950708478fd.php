<img src="<?php echo e(asset('images/gfyservicios-nuevo-logo.png')); ?>"
     alt="GF7 Ingeniería y Servicios"
     <?php echo e($attributes->merge(['class' => 'object-contain'])); ?>>
<?php /**PATH D:\wamp64\www\qrfy\qrfy-app\resources\views\components\company-logo.blade.php ENDPATH**/ ?>