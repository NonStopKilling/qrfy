<?php $__env->startSection('title', 'Mantenimiento | QRFY'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-6xl space-y-6">
    <section class="rounded-3xl border border-slate-200 bg-white p-6 shadow-xl">
        <p class="text-xs uppercase tracking-[0.2em] text-slate-500">Mantenimiento vinculado al QR</p>
        <h2 class="title-font mt-1 text-3xl font-bold text-slate-900">Hoja de vida: <?php echo e($asset->name); ?></h2>
        <p class="mt-2 text-slate-500"><?php echo e($asset->qr_code); ?> · Serie <?php echo e($asset->serial_number); ?></p>

        <?php if(session('success')): ?><div class="mt-5 rounded-2xl border border-green-200 bg-green-50 p-4 text-green-700"><?php echo e(session('success')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?><div class="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700"><?php echo e($errors->first()); ?></div><?php endif; ?>

        <div class="mt-6 grid gap-6 lg:grid-cols-2">
            <div class="space-y-3">
                <div class="rounded-2xl border border-slate-200 p-4">
                    <p class="text-sm font-semibold text-slate-900">Historial</p>
                    <ol class="mt-3 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $asset->maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="rounded-xl border border-slate-200 p-3">
                                <p class="text-xs font-semibold text-slate-500"><?php echo e(optional($maintenance->performed_at)->format('d-m-Y H:i')); ?></p>
                                <p class="mt-1 text-slate-700"><?php echo e($maintenance->description); ?></p>
                                <?php if($maintenance->digital_signature): ?><p class="mt-2 text-xs text-slate-500">Firma: <?php echo e($maintenance->digital_signature); ?></p><?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="rounded-xl border border-dashed border-slate-300 p-5 text-center text-slate-500">Sin mantenimientos registrados.</li>
                        <?php endif; ?>
                    </ol>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('dashboard.maintenance.store', ['asset' => $asset, 'role' => $role])); ?>" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div><label class="mb-2 block text-sm font-semibold text-slate-700">Fecha y hora</label><input name="performed_at" type="datetime-local" value="<?php echo e(old('performed_at', now()->format('Y-m-d\TH:i'))); ?>" required class="w-full rounded-2xl border border-slate-300 px-4 py-3"></div>
                <div><label class="mb-2 block text-sm font-semibold text-slate-700">Descripción técnica</label><textarea name="description" rows="5" required minlength="12" class="w-full rounded-2xl border border-slate-300 px-4 py-3" placeholder="Detalle del trabajo realizado"><?php echo e(old('description')); ?></textarea></div>
                <div class="grid gap-3 sm:grid-cols-2">
                    <div><label class="mb-2 block text-sm font-semibold text-slate-700">Foto antes</label><input name="before_photo" type="file" accept="image/*" class="w-full rounded-2xl border border-slate-300 px-3 py-2"></div>
                    <div><label class="mb-2 block text-sm font-semibold text-slate-700">Foto después</label><input name="after_photo" type="file" accept="image/*" class="w-full rounded-2xl border border-slate-300 px-3 py-2"></div>
                </div>
                <div><label class="mb-2 block text-sm font-semibold text-slate-700">Firma digital</label><input name="digital_signature" value="<?php echo e(old('digital_signature')); ?>" type="text" class="w-full rounded-2xl border border-slate-300 px-4 py-3" placeholder="Nombre completo"></div>
                <div class="flex flex-wrap gap-3"><button class="rounded-2xl bg-[var(--corp-blue)] px-5 py-3 font-semibold text-white hover:brightness-90">Guardar mantenimiento</button><a href="<?php echo e(route('dashboard.assets.show', ['asset' => $asset, 'role' => $role])); ?>" class="rounded-2xl border border-slate-300 px-5 py-3 font-semibold">Volver al activo</a></div>
            </form>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\qrfy\qrfy-app\resources\views/dashboard/maintenance/show.blade.php ENDPATH**/ ?>